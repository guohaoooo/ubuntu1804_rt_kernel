/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _LINUX_IOCTL_H
#define _LINUX_IOCTL_H

#include <asm/ioctl.h>

#endif /* _LINUX_IOCTL_H */

